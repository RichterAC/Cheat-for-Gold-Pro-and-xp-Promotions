created by RichterAC
; Cheat Civilization mod for Unciv (Kingdom)
(Gold 100000)
(Food 100)
(Production 10000)
(XpForNewUnits 9999)
(Pathfinder,Siedler(Settler),Super-Bogenschütze(Archer) 100 Movements)
(Promotions for Pathfinder ~20 Visibility Super-Bogenschütze ~20 Range *not tesded*)

v1.00 08.03.2021

